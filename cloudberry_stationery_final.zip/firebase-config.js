
// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB4UvaVK5L6Brb2uiVEkqBwft3YGD63yzk",
  authDomain: "cloudberystationary.firebaseapp.com",
  projectId: "cloudberystationary",
  storageBucket: "cloudberystationary.appspot.com",
  messagingSenderId: "347854528750",
  appId: "1:347854528750:web:d5cf065b4c8379058853ff",
  measurementId: "G-JME9HP5L44"
};

firebase.initializeApp(firebaseConfig);
