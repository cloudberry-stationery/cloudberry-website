
// Firebase auth functions
firebase.auth().onAuthStateChanged(user => {
  if (user) {
    console.log('User is logged in:', user.email);
  } else {
    console.log('User is logged out');
  }
});
